/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myn2;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author meen
 */
public class SelectedCode {
    private static int N = 150_000;
    private static Random r = new Random();
    public static void main(String[] args) {
        Integer[] a1 = new Integer[N];
        Integer[] a2 = new Integer[N];
        Integer[] a3 = new Integer[N];
        initial(a1);
        System.arraycopy(a1, 0, a2, 0, a1.length);
        System.arraycopy(a1, 0, a3, 0, a1.length);
        
        long begin = System.currentTimeMillis();
        for( int i = 1; i< a1.length; i++){
            int tmp = a1[i];
            int j = i-1;
            
            for (; j >= 0 && a1[j] > tmp; j--){
                a1[j + 1] = a1[j];
            }
            a1[j+1] = tmp;
        }
        System.out.println("Duration " + (System.currentTimeMillis()- begin) + " milliseconds");
    }
    private static void initial(Integer[]a1){
        for (int i =0; i< a1.length ; i++){
            a1[i] = r.nextInt(N);
        }
    }
}
